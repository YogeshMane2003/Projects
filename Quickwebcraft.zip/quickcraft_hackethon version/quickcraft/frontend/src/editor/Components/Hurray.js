import { useToggle } from "../../config";
import "../index.css";
import React from "react";
import {
  Button,
  Modal,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "@nextui-org/react";

function Hurray({ type, url }) {
  const { showHurrayModal, setShowHurrayModal } = useToggle();

  return (
    <Modal
      backdrop="blur"
      isOpen={showHurrayModal}
      onClose={() => setShowHurrayModal(false)}
      placement="top-center"
      showCloseButton={false}
    >
      <ModalContent
        className="bg-gray-100 p-5 rounded-lg shadow-lg"
        style={{
          zIndex: 20,
        }}
      >
        {() => (
          <>
            <ModalHeader className="flex justify-between items-center">
              <span>Your site is LIVE</span>
            </ModalHeader>
            <ModalBody>
              <h2 className="text-4xl text-center font-extrabold mb-4 font-mono ">
                🎉Boom!
              </h2>

              <h4
                onPress={() => {
                  setShowHurrayModal(false);
                  window.open(
                    type === "Subdomain"
                      ? "https://" + url + ".toggl.site"
                      : "https://" + url,
                    "_blank"
                  );
                }}
                className="text-1xl text-center font-extrabold mb-4 font-mono "
              >
                {type === "Subdomain"
                  ? "https://" + url + ".toggl.site"
                  : "https://" + url}
              </h4>
              <p className="text-gray-600 font-medium">
                Your website is published!
              </p>
            </ModalBody>
            <ModalFooter>
              <Button
                className="bg-[#CD2504] text-white px-4 py-2 rounded-md transition-all"
                color="primary"
                onPress={() => {
                  setShowHurrayModal(false);
                  window.open(
                    type === "Subdomain"
                      ? "https://" + url + ".toggl.site"
                      : "https://" + url,
                    "_blank"
                  );
                }}
              >
                Visit
              </Button>
            </ModalFooter>
          </>
        )}
      </ModalContent>
    </Modal>
  );
}

export default Hurray;
