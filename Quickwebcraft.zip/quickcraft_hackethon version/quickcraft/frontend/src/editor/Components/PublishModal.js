import { useToggle } from '../../config';
import '../index.css';
import React, { useRef, useState } from 'react';
import {
    Button,
    Modal, ModalContent, ModalHeader, ModalBody, ModalFooter, Input
} from "@nextui-org/react";

import { Accordion, AccordionItem } from "@nextui-org/react";
import axios from 'axios';
import Hurray from './Hurray';

function PublishModal() {
    const { showPublishModal, setShowPublishModal, site, setShowHurrayModal} = useToggle();
    const subdomainRef = useRef(null);
    const domainRef = useRef(null);

    // State for validation errors
    const [subdomainError, setSubdomainError] = useState('');
    const [domainError, setDomainError] = useState('');

    // Validate subdomain and domain
    const validateInputs = () => {
        let isValid = true;

        // Reset errors
        setSubdomainError('');
        setDomainError('');

        // Subdomain validation: check if it's not empty
        if (subdomainRef.current && !subdomainRef.current.value.trim()) {
            setSubdomainError('Subdomain is required');
            isValid = false;
        }

        // Domain validation: check if it's a valid URL format
        if (domainRef.current && domainRef.current.value.trim()) {
            const urlPattern = /^(https?:\/\/)?([a-zA-Z0-9]+[-\.])*[a-zA-Z0-9]{2,}\.[a-zA-Z]{2,}(\/.*)?$/;
            if (!urlPattern.test(domainRef.current.value)) {
                setDomainError('Please enter a valid domain URL');
                isValid = false;
            }
        }

        return isValid;
    };

    const updatedomain = (siteid) => {
        if (validateInputs()) {
            if (subdomainRef.current) {
                axios.post(process.env.REACT_APP_API_URL + '/updatesubdomain', {
                    _id: siteid,
                    domain: '',
                    subdomain: subdomainRef.current.value
                }).then((result) => {
                    if (result.data.message === "Updated") {
                        setShowHurrayModal(true);
                        setShowPublishModal(false);
                    }
                });
            }

            if (domainRef.current) {
                axios.post(process.env.REACT_APP_API_URL + '/updatedomain', {
                    _id: siteid,
                    domain: domainRef.current.value,
                    subdomain: ''
                }).then((result) => {
                    if (result.data.message === "Updated") {
                        setShowHurrayModal(true);
                        setShowPublishModal(false);
                    }
                });
            }
        }
    };

    return (
        <>
            <div
                className={`fixed inset-0 ${showPublishModal ? 'backdrop-blur-sm bg-black/30' : ''} z-10`}
                style={{ display: showPublishModal ? 'block' : 'none' }}
            >
                <Modal
                    isOpen={showPublishModal}
                    onClose={() => setShowPublishModal(false)}
                    placement="top-center"
                    showCloseButton={false}
                >
                    <ModalContent
                        className="bg-gray-100 p-5 rounded-lg shadow-lg"
                        style={{
                            zIndex: 20,
                        }}
                    >
                        {() => (
                            <>
                                <ModalHeader className="flex justify-between items-center">
                                    <span>Choose a domain before you publish</span>
                                </ModalHeader>
                                <ModalBody>
                                    <Accordion defaultExpandedKeys="1">
                                        <AccordionItem key="1" aria-label="Get a free webcraft domain" title="Get a free webcraft domain">
                                            <Input
                                                type="text"
                                                className="outline-none outline-blue-100 hover:outline hover:outline-blue-400"
                                                ref={subdomainRef}
                                                placeholder="yourwebsitename"
                                                labelPlacement="outside"
                                                startContent={
                                                    <div className="pointer-events-none flex items-center">
                                                        <span className="text-gray-500 text-sm">https://</span>
                                                    </div>
                                                }
                                                endContent={
                                                    <div className="pointer-events-none flex items-center">
                                                        <span className="text-gray-500 text-sm">.webcraft.app</span>
                                                    </div>
                                                }
                                                required
                                            />
                                            {subdomainError && <div className="text-red-500 text-sm">{subdomainError}</div>}
                                        </AccordionItem>
                                        <AccordionItem key="2" aria-label="Connect your own customized domain" title="Connect your own customized domain">
                                            <Input
                                                type="url"
                                                className="outline-none outline-blue-100 hover:outline hover:outline-blue-400"
                                                ref={domainRef}
                                                placeholder="yourdomain.com"
                                                labelPlacement="outside"
                                                startContent={
                                                    <div className="pointer-events-none flex items-center">
                                                        <span className="text-default-400 text-small">https://</span>
                                                    </div>
                                                }
                                            />
                                            {domainError && <div className="text-red-500 text-sm">{domainError}</div>}
                                        </AccordionItem>
                                    </Accordion>
                                </ModalBody>

                                <ModalFooter>
                                    <Button
                                        color="primary"
                                        className="bg-[#CD2504] text-white px-4 py-2 rounded-md transition-all"
                                        onPress={() => updatedomain(site[0]._id)}
                                    >
                                        Publish
                                    </Button>
                                </ModalFooter>
                            </>
                        )}
                    </ModalContent>
                </Modal>
            </div>

            <Hurray type={subdomainRef.current ? 'Subdomain' : 'Domain'} url={subdomainRef.current ? subdomainRef.current.value : domainRef.current ? domainRef.current.value : null} />
        </>
    );
}

export default PublishModal;
