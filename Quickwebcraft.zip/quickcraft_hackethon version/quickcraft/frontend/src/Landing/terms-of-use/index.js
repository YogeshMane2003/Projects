import React from 'react';
import { useState } from 'react';
import Nav from './navbar';
import { useNavigate } from 'react-router-dom';
import './index.css';

const TermsOfUse = () => {
    const [agreed, setAgreed] = useState(false);
    const navigate = useNavigate();

    const handleContinue = () => {
        if (agreed) {
          navigate('/'); // Redirect to Landing Page
        }
      };
    
  return (
    <div className="TermsOfUse">
        <Nav />
        <div className="terms-container">
      <h1>Terms of Use</h1>
      <p><strong>Last updated:</strong> October 01, 2024</p>

      <p>These Terms of Use ("Terms") govern your access to and use of the QuickWebCraft platform ("Service") operated by QuickWebCraft ("Company", "We", "Us", or "Our"). By accessing or using the Service, You agree to be bound by these Terms. If You disagree with any part of the Terms, then You may not access the Service.</p>

      <h2>Use of the Service</h2>
      <p>You must be at least 13 years old to use this Service. By using the Service, You represent that You meet this age requirement.</p>
      <p>You agree to use the Service only for lawful purposes. You are responsible for ensuring that your use of the Service does not violate any applicable laws or regulations.</p>

      <h2>Accounts</h2>
      <p>When You create an account with Us, You must provide Us with information that is accurate, complete, and current. Failure to do so may result in immediate termination of Your account.</p>
      <p>You are responsible for safeguarding your password and for any activities or actions under your account.</p>

      <h2>Intellectual Property</h2>
      <p>The Service and its original content, features, and functionality are the exclusive property of QuickWebCraft and its licensors, protected by copyright and other intellectual property laws.</p>

      <h2>User Content</h2>
      <p>You retain ownership of any content You post or upload through the Service. By posting content, You grant Us a license to use, display, and modify it as needed to operate the Service.</p>

      <h2>Prohibited Uses</h2>
      <ul>
        <li>Use the Service for any unlawful purpose.</li>
        <li>Transmit malware or harmful code.</li>
        <li>Attempt unauthorized access to other accounts.</li>
        <li>Disrupt the integrity or performance of the platform.</li>
      </ul>

      <h2>Termination</h2>
      <p>We may suspend or terminate Your account at any time if You violate these Terms. Upon termination, Your right to use the Service will immediately cease.</p>

      <h2>Limitation of Liability</h2>
      <p>To the fullest extent permitted by law, QuickWebCraft will not be liable for any indirect or consequential damages arising out of Your use of the Service.</p>

      <h2>Changes to These Terms</h2>
      <p>We may update these Terms from time to time. You are encouraged to review them regularly. Continued use of the Service after changes means You accept the new Terms.</p>

      <h2>Contact Us</h2>
      <p>If You have any questions about these Terms, contact us at <strong>support@quickwebcraft.app</strong></p>
      <div className="agreement-section">
        <input
          type="checkbox"
          id="terms-agree"
          checked={agreed}
          onChange={(e) => setAgreed(e.target.checked)}
        />
        <label htmlFor="terms-agree">I agree to the Terms of Use</label>
      </div>

      {/* Optional Button */}
      <button disabled={!agreed} onClick={handleContinue}>Continue</button>
    </div>
    </div>
  );
};

export default TermsOfUse;
