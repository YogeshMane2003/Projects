import './Nav.css';

function Nav() {


    return (
        <div className="Nav">
            <div className='Logo'>Quickwebcraft</div>
        </div>
    );
}

export default Nav;
