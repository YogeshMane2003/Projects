import React, { useState } from 'react';
import './index.css';
import { useNavigate } from 'react-router-dom';
import Nav from './navbar';

const PrivacyPolicy = () => {
  const [agreed, setAgreed] = useState(false);
  const navigate = useNavigate();

  const handleContinue = () => {
    if (agreed) {
      navigate('/');
    }
  };

  return (
    <div className="PrivacyPolicy">
      <Nav />
      <div className="policy-container">
        <h1>Privacy Policy</h1>
        <p><strong>Last updated:</strong> October 01, 2024</p>

        <ol>
          <li>
            <strong>Introduction</strong>
            <p>
              This Privacy Policy describes our policies and procedures on the collection, use, and disclosure
              of your information when you use the Service and informs you about your privacy rights and how
              the law protects you.
            </p>
            <p>
              We use your personal data to provide and improve the Service. By using the Service, you agree
              to the collection and use of information in accordance with this Privacy Policy.
            </p>
          </li>

          <li>
            <strong>Interpretation and Definitions</strong>
            <ol type="a">
              <li>
                <strong>Interpretation</strong>
                <p>
                  Words with capitalized initials have meanings defined under the conditions below.
                </p>
              </li>
              <li>
                <strong>Definitions</strong>
                <p>For the purposes of this Privacy Policy:</p>
                <ol>
                  <li><strong>Account:</strong> A unique account created for you to access our Service.</li>
                  <li><strong>Affiliate:</strong> An entity under common control with the Company.</li>
                  <li><strong>Company:</strong> Refers to QuickWebCraft, Dharma Hight.</li>
                  <li><strong>Cookies:</strong> Small files stored on your device for tracking and analytics.</li>
                  <li><strong>Country:</strong> Refers to Maharashtra, India.</li>
                  <li><strong>Device:</strong> Any device like computer, phone, or tablet.</li>
                  <li><strong>Personal Data:</strong> Any info that identifies an individual.</li>
                  <li><strong>Service:</strong> Refers to the QuickWebCraft website.</li>
                  <li><strong>Service Provider:</strong> Third-party entities that help us provide the Service.</li>
                  <li><strong>Third-party Social Media Service:</strong> Platforms for logging in or sharing.</li>
                  <li><strong>Usage Data:</strong> Data collected automatically (e.g., duration of page visits).</li>
                  <li>
                    <strong>Website:</strong> QuickWebCraft, accessible at{' '}
                    <a href='https://QuickWebCraft.app' target='_blank' rel='noopener noreferrer'>
                      QuickWebCraft.app
                    </a>.
                  </li>
                  <li>
                    <strong>You:</strong> The individual or entity accessing the Service.
                  </li>
                </ol>
              </li>
            </ol>
          </li>
        </ol>

        <div className="agreement-section">
          <input
            type="checkbox"
            id="privacy-agree"
            checked={agreed}
            onChange={(e) => setAgreed(e.target.checked)}
          />
          <label htmlFor="privacy-agree"> I agree to the Privacy Policy</label>
        </div>

        <button disabled={!agreed} onClick={handleContinue}>
          Continue
        </button>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
