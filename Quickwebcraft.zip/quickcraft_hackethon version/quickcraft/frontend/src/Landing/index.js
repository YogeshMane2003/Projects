import "./index.css";
import portfolio from '../assets/portfolio.png';
import portfolio1 from '../assets/portfolio1.png';
import landing from '../assets/landing.png';
import ecommerce from '../assets/ecommerce.png';
import ecommerce1 from '../assets/ecommerce1.png';
import ecommerce2 from '../assets/ecommerce2.png';
import educate from '../assets/educate.png';
import blog from '../assets/blog.png'; // Go up one level from 'Landing' to 'src'

import { Marquee } from "@devnomic/marquee";
import "@devnomic/marquee/dist/index.css";
import React, { useEffect } from "react";

function LandingPage() {
  const handleRedirect = () => {
    const userId = localStorage.getItem("userid");
    if (userId) {
      window.location.replace(`/projects/${userId}`);
    }
  };

  useEffect(() => {
    handleRedirect();
  }, []);
  
  return (
    <div className="LandingPage">
        <div className="Nav">
          <div className="Logo">Quickwebcraft</div>
          <div className="Btns">
            {/* <button>Pricing</button> */}
            <button onClick={() => (window.location.href = "/signup")}>
              Login
            </button>
          </div>
        </div>

        <div className="HeroSection">
          <div className="MainLine">
            Build a website
            <br />
            in just a <span>second!</span>
          </div>
          <button onClick={() => (window.location.href = "/signup")}>
            Create your Website
          </button>
        </div>

        <div className="TrendingTemplates">
          <div className="Title">Trending Templates</div>
          <div className="templateswrap">
            <div className="templates">
            <a
      href="https://res.cloudinary.com/dmwhg18or/image/upload/v1735548296/Screenshot_2024-12-30_141431_er5xrg.png"
      target="_blank"
      rel="noopener noreferrer"
      style={{ textDecoration: 'none' }}
    >
      <div
        style={{
          background: `url(${portfolio})`,
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          height: '300px',
          cursor: 'pointer',
        }}
        className="templates"
      >
        {/* Optional content inside */}
      </div>
    </a>
    <a
      href="https://res.cloudinary.com/dbfzen2pt/image/upload/v1735671944/lz9hqmaqreciukf45irw.png"
      target="_blank"
      rel="noopener noreferrer"
      style={{ textDecoration: 'none' }}
    >
      <div
        style={{
          background: `url(${portfolio1})`,
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          height: '300px',
          cursor: 'pointer',
        }}
        className="templates"
      >
        {/* Optional content inside */}
      </div>
    </a>
    <a
      href="https://res.cloudinary.com/dbfzen2pt/image/upload/v1735569960/fvn0754yuttfbbol0vas.png"
      target="_blank"
      rel="noopener noreferrer"
      style={{ textDecoration: 'none' }}
    >
      <div
        style={{
          background: `url(${ecommerce})`,
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          height: '300px',
          cursor: 'pointer',
        }}
        className="templates"
      >
        {/* Optional content inside */}
      </div>
    </a>
    <a
      href="https://res.cloudinary.com/dbfzen2pt/image/upload/v1735672012/l9missvejlqkuyekqwlm.png"
      target="_blank"
      rel="noopener noreferrer"
      style={{ textDecoration: 'none' }}
    >
      <div
        style={{
          background: `url(${ecommerce1})`,
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          height: '300px',
          cursor: 'pointer',
        }}
        className="templates"
      >
        {/* Optional content inside */}
      </div>
    </a>
    <a
      href="https://res.cloudinary.com/dmwhg18or/image/upload/v1737480903/Screenshot_2025-01-21_230256_zich6v.png"
      target="_blank"
      rel="noopener noreferrer"
      style={{ textDecoration: 'none' }}
    >
      <div
        style={{
          background: `url(${ecommerce2})`,
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          height: '300px',
          cursor: 'pointer',
        }}
        className="templates"
      >
        {/* Optional content inside */}
      </div>
    </a>
    <a
      href="https://res.cloudinary.com/dbfzen2pt/image/upload/v1735670101/xchuaox0v35n0ee5s8oa.png"
      target="_blank"
      rel="noopener noreferrer"
      style={{ textDecoration: 'none' }}
    >
      <div
        style={{
          background: `url(${educate})`,
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          height: '300px',
          cursor: 'pointer',
        }}
        className="templates"
      >
        {/* Optional content inside */}
      </div>
    </a>
    <a
      href="https://res.cloudinary.com/dbfzen2pt/image/upload/v1735569973/u0arep2gdkl0ixke4ens.png"
      target="_blank"
      rel="noopener noreferrer"
      style={{ textDecoration: 'none' }}
    >
      <div
        style={{
          background: `url(${blog})`,
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          height: '300px',
          cursor: 'pointer',
        }}
        className="templates"
      >
        {/* Optional content inside */}
      </div>
    </a>
    <a
      href="https://res.cloudinary.com/dnbf9z1yg/image/upload/v1727791965/qrmaqvlhkzrcu5ykinhc.png"
      target="_blank"
      rel="noopener noreferrer"
      style={{ textDecoration: 'none' }}
    >
      <div
        style={{
          background: `url(${landing})`,
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          height: '300px',
          cursor: 'pointer',
        }}
        className="templates"
      >
        {/* Optional content inside */}
      </div>
    </a>
            </div>
          </div>
        </div>

        <div className="Testimonials">
          <div className="MainLine">What People Are Saying</div>
          <div className="SubLine">
            Don't just take our word for it. Here's what real people are
            <br />
            saying about Quickwebcraft.
          </div>

          <Marquee className="marquee" fade={true}>
            <div className="tweet">
              <div className="top">
                <div className="left">
                  <img
                    alt="img"
                    src={
                      "https://media.licdn.com/dms/image/v2/D5603AQFRthKe3lVeZQ/profile-displayphoto-shrink_100_100/profile-displayphoto-shrink_100_100/0/1711195476006?e=1749686400&v=beta&t=NqDjJLqihf4nei9oB-buLGK3-BGtb7S5KjpP58o4kW8"
                    }
                  />
                  <div className="info">
                    <div className="name">Vikas Patil</div>
                    <div className="username">viky.patil38@gmail.com</div>
                  </div>
                </div>
              </div>
              <div className="msg"> User Experience is really awesome!🔥 keep it up.</div>
            </div>
            <div className="tweet">
              <div className="top">
                <div className="left">
                  <img
                    alt="img"
                    src={
                      "https://media.licdn.com/dms/image/v2/D4D03AQEQ7HtY-v4KWw/profile-displayphoto-shrink_100_100/profile-displayphoto-shrink_100_100/0/1675141579363?e=1749686400&v=beta&t=Mq9FkJ1jgCSJs9vJKbIjKQPq-rPpGFZQ5AKImk4P4ac"
                    }
                  />
                  <div className="info">
                    <div className="name">Sandesh Varpe</div>
                    <div className="username">sandeshvarpe3233@gmail.com</div>
                  </div>
                </div>
              </div>
              <div className="msg">Okay this is amazing.</div>
            </div>
            <div className="tweet">
              <div className="top">
                <div className="left">
                  <img
                    alt="img"
                    src={
                      "https://media.licdn.com/dms/image/v2/D4D03AQHV_UKyZbq1Mg/profile-displayphoto-shrink_100_100/profile-displayphoto-shrink_100_100/0/1725025886886?e=1749686400&v=beta&t=Y1Y044icKtiwH7aGxhrHPlNuFv7B9RnGTGZqLALungo"
                    }
                  />
                  <div className="info">
                    <div className="name">Appaji Patil</div>
                    <div className="username">appajipatilmh547@gmail.com</div>
                  </div>
                </div>
              </div>
              <div className="msg">
                I was looking for something like that yesterday. Well done and
                tks for sharing!
              </div>
            </div>
            <div className="tweet">
              <div className="top">
                <div className="left">
                  <img
                    alt="img"
                    src={
                      "https://media.licdn.com/dms/image/v2/D4D35AQFeBN5je-AN0Q/profile-framedphoto-shrink_100_100/profile-framedphoto-shrink_100_100/0/1733636591234?e=1744974000&v=beta&t=xzQe4SoEuwvXfWfpHTtDrwRmVRs0uN8Wu9aokL1RCyc"
                    }
                  />
                  <div className="info">
                    <div className="name">Saif Ustad</div>
                    <div className="username">saifustad1111@gmail.com</div>
                  </div>
                </div>
              </div>
              <div className="msg">This is awesome 👏</div>
            </div>
            <div className="tweet">
              <div className="top">
                <div className="left">
                  <img
                    alt="img"
                    src={
                      "https://media.licdn.com/dms/image/v2/D5603AQHoZxznH04teQ/profile-displayphoto-shrink_100_100/B56ZN9Y3PfGgAU-/0/1732975493926?e=1749686400&v=beta&t=h8Fr0fUPhh4iHE7mDUhgjyxNYvvGUUlbIEzDPNvR1QM"
                    }
                  />
                  <div className="info">
                    <div className="name">Karan  Sawant</div>
                    <div className="username">karansawant2218@gmail.com</div>
                  </div>
                </div>
              </div>
              <div className="msg">bro this is so good.</div>
            </div>
          </Marquee>
        </div>
        <div className="LastCall">
          <div className="circle"></div>

          <div className="lastform">
            <div className="title">Get Started Today and Build the Website of Your Dreams!</div>
            <button onClick={() => (window.location.href = "/signup")}>
              Get started for free
            </button>
          </div>
        </div>

        <div className="Footer">
          <div className="footerright">
                  <img
              onClick={() => window.location.href = 'https://www.instagram.com/toggl.hq/'}
              alt="img"
              src={
                "https://www.transparentpng.com/download/logo-instagram/SKq9yH-black-and-white-instagram-logo-png.png"
              }
            />
            <img
            onClick={() => window.location.href = 'https://x.com/togglhq/'}
              alt="img"
              src={
                "https://static.vecteezy.com/system/resources/thumbnails/026/406/678/small_2x/social-media-x-logo-black-and-white-free-vector.jpg"
              }
            />
            <img
              onClick={() => window.location.href = 'https://linkedin.com/company/togglhq'}
              alt="img"
              src={
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSVoaJCn9oFy4qI_1da_MTw-IKnVZy1zLe51qvhsyzmXnfJclZ0IqdfyakD5pVeajmh2F0&usqp=CAU"
              }
            />
          </div>
          <div className="links">
            <a href="/terms-of-use">Terms of Use</a>
            <a href="/privacy-policy">Privacy Policy</a>
          
          </div>

        </div>
    </div>
  );
}

export default LandingPage;
